## Start Blog Container

```
docker-compose up -d
```

### Wordpress - first time setup

```
cd blog
docker exec -it wordpresscontainer id bash
mkdir blog
mv * blog
mv .htaccess .htaccess.bck
apt update
apt install nano -y
nano .htaccess
exit

```

Restart docker

```
docker-compose restart
```