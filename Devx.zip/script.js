$("#form").submit(function (e) {
    console.log('Submitting')
    e.preventDefault();
    document.getElementById('submit-preloader').style.display = "inline";
    var form = $(this);
    var form_values = form.serialize();
    console.log('Form data', form_values)
    $.post('https://leads.phidesigns.in', form_values, function (data) {
        console.log('Submitted response', data);
        window.location.href = window.location.origin + "/thank-you";
    })
});

function scrollToTop() {
    document.body.scrollTop = 0
    document.documentElement.scrollTop = 0;
}

window.onload = () => {
    document.getElementById("year").innerHTML = new Date().getFullYear();
    document.body.style.opacity = '1';
    document.getElementById("preloader").style.opacity = "0";
    setTimeout(() => {
        document.getElementById("preloader").style.display = "none";
    }, 501);
}

function menuBtnFunction(menuBtn) {
    menuBtn.classList.toggle("active");
}

const navbar = document.getElementById("navbar");
const spacer = document.getElementById("spacer");

navbar.addEventListener('resize', () => {
    spacer.style.height = navbar.clientHeight + "px";
})

window.addEventListener("load", () => {
    spacer.style.height = navbar.clientHeight + "px";
})

let closeBtn = document.getElementById("closeBtn");
let contactLink = document.getElementById("contactBtn");

contactLink.addEventListener('click', () => {
    if (window.innerWidth <= 768) {
        closeBtn.click();
    }
})