sudo apt update
sudo apt updgrade -y

# Install  Nodejs
curl -sL https://deb.nodesource.com/setup_14.x | sudo -E bash -
yes | sudo apt install nodejs

# Install pm2
sudo npm install pm2 -g

# Install yarn
sudo npm install -g yarn

# Install Caddy on Ubuntu 20.04
# Source: https://www.hostnextra.com/kb/how-to-install-caddy-on-ubuntu-20-04/
curl -1sLf ‘https://dl.cloudsmith.io/public/caddy/stable/gpg.key’ | sudo apt-key add –
curl -1sLf ‘https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt’ | sudo tee -a /etc/apt/sources.list.d/caddy-stable.list
sudo apt update
sudo apt install caddy
sudo mv /etc/caddy/Caddyfile /etc/caddy/Caddyfile.bak
sudo touch /etc/caddy/Caddyfile

# Install AWSCLI
sudo apt install awscli -y

# Install codedeploy agent
sudo apt install ruby-full
sudo apt install wget
cd /home/ubuntu
wget https://aws-codedeploy-ap-south-1.s3.ap-south-1.amazonaws.com/latest/install
chmod +x ./install
sudo ./install auto
sudo service codedeploy-agent status
sudo service codedeploy-agent start
sudo service codedeploy-agent status

rm -rf /home/ubuntu/install