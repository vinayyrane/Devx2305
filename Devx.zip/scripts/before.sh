# rm -rf /home/ubuntu/phidesigns-website/*

if [ ! -d /home/ubuntu/phidesigns-website ]; then
    mkdir -vp /home/ubuntu/phidesigns-website
fi


